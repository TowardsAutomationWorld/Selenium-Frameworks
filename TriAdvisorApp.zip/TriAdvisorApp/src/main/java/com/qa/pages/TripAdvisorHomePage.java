package com.qa.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;

public class TripAdvisorHomePage extends TestBase {

	public TripAdvisorHomePage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='component_1']/div/div[2]/div/form/input[1]")
	WebElement tripsearchTextboxClick1;

	// @FindBy(xpath = "//div[@id='component_4']/div/div/form/input[1]")
	// WebElement tripsearchTextboxClick2;

	@FindBy(xpath = "//div[@title = 'Search']")
	WebElement tripsearchTextboxClick;

	// @FindBy(xpath = "//div[@title = 'Search']")
	// WebElement tripsearchTextboxClick;

	@FindBy(xpath = "//div[@id='component_4']/div/div/form/input[1]")
	WebElement tripsearchTextbox1;

	@FindBy(xpath = "//input[@id='mainSearch']")
	WebElement tripsearchTextbox;

	@FindBy(xpath = "//div[@id='component_4']/div/div/form/button[3]")
	WebElement searchButtonIcon;

	@FindBy(xpath = "//button[@id='SEARCH_BUTTON']")
	WebElement searchButton;

	@FindBy(xpath = "//input[@class='_3qLQ-U8m']")
	WebElement searchButtonTop;

	@FindBy(xpath = "//div[@class = '_27pk-lCQ']/a[2]")
	WebElement searchResultFirstItem;

	public void enterProductNameToSearch() {
		try {
			tripsearchTextboxClick.click();
			tripsearchTextbox.sendKeys("Club Mahindra");
			searchButton.click();
		} catch (Exception e) {
			System.out.println("");
		}

		try {
			tripsearchTextboxClick1.click();
			tripsearchTextbox1.sendKeys("Club Mahindra");
		} catch (Exception e) {
			System.out.println("");
		}

		try {
			tripsearchTextboxClick.click();
			tripsearchTextbox.sendKeys("Club Mahindra");
		} catch (Exception e) {
			System.out.println("");
		}

		try {
			searchButtonTop.click();
			searchButtonTop.sendKeys("Club Mahindra");
		} catch (Exception e) {
			System.out.println("");
		}

	}

	public void clickOnSearchButton() throws AWTException {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	public void clickOnSearchResultFirstItem() throws InterruptedException {
		Thread.sleep(3000);
		searchResultFirstItem.click();

	}

	public TripAdvisorHotelReviewPage navigateToReviewPage() {
		return new TripAdvisorHotelReviewPage();

	}

}
